# Projet_SI
An application to detect the movement of a chicken. Tech:Python, PyQt5, opencv.
